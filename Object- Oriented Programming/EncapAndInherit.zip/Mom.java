public class Mom {
    //INHERITANCE->inherit from parents
    //namamana
    //MOM CLASS
    //Properties of the Parent/Super 
    public String skinColor;
    public String eyeColor;
    public String hairColor;

    public Mom(){
        this.skinColor = "LighBrown";
        this.eyeColor = "brown";
        this.hairColor = "Red";
    }

    void canWalk(){
        System.out.println("Mom can walk!");
    }

    void canSing(){
        System.out.println("Mom can sing!");
    }

    void canCook(){
        System.out.println("Mom can cook!");
    }
}
