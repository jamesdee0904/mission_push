public class Anak extends Mom {
    //INHERITANCE -> inheriting attributes from the superclass of base class
    //extends -> 

    //Method Overriding
    //@Override annotations.

    @Override
    void canSing(){
        System.out.println("Anak can sing!");
    }

    void canWrite(){
        System.out.println("Anak can write");
    }

    
}
