public class Student {

    //ENCAPSULATION-> data security

    //Instance variable
    // private double studentGrades;

    // //GETTER AND SETTER METHOD

    // //SETTER -> WRITE ONLY
    // //SETTER METHOD-> initialize the private variables if the given condition is true
    // void setStudentGrades(double studentGrades){
    //     if(studentGrades > 0){
    //         this.studentGrades  = studentGrades;
    //     }else{
    //         System.out.println("Grade Invalid!");
    //     }
    // }
    // //GETTER METHOD-> READ ONLY
    // public double getStudentGrades(){
    //     return studentGrades;
    // }

    private String accName; //ALEN
    private double bankBalance; //1000
    
    //Setter method -> validation
    void setAccName(String accName){
        if(!accName.equals(null) && !accName.equals(" ")){
            this.accName = accName;
        }else{
            System.out.println("Acc Name invalid");
        }
    }

    void setBankBalance(double bankBalance){
        if(bankBalance >= 1000){
            this.bankBalance = bankBalance;
        }else{
            System.out.println("Invalid Balance");
        }

    }

    public String getAccName(){
        return accName;
    }

    public double getBankBalance(){
        return bankBalance;
    }

}
