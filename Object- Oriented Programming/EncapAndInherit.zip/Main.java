public class Main {
    public static void main(String[] args) {

        //PILLARS of OOP
        //Foundation 
        //4 PILLARS {ENCAPSULATION, INHERITANCE, POLYMORPHISM, ABSTRACTION}
        //Encapsulation-> encapsulate the varible
        //variable-> we can store data and we definitly manipulate

        // Student student = new Student();

        // student.setStudentGrades(1.0);

        // System.out.println("Your Grade is: " + student.getStudentGrades());
        
        // student.setStudentGrades(1.5);
        // System.out.println("Your Grade is: " + student.getStudentGrades());

        // student.setAccName("Alen");
        // System.out.println("Your Account name: " + student.getAccName());

        // student.setBankBalance(1000);
        // System.out.println("Your Balance is: " + student.getBankBalance());

        // student.setBankBalance(500);
        // System.out.println("Your Balance is: " + student.getBankBalance());


        Mom mom = new Mom();
        mom.canWalk();
        mom.canSing();
        mom.canCook();

        System.out.println("********************");

        Anak anak = new Anak();
        System.out.println(anak.eyeColor);
        System.out.println(anak.hairColor);
        System.out.println(anak.skinColor);

        anak.canSing();
        anak.canWrite();





    }
}
